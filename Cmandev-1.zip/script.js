window.onload = function() {
  if (Math.random() < 0.8) {
    window.location.replace("https://www.youtube.com/watch?v=JmCz_AE_x9g");
  } else {
    window.location.replace("https://www.youtube.com/watch?v=p7YXXieghto");
  }
};